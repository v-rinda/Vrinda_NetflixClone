 import React from 'react';
 import Header from "../component/Header/Header";
 import TabComponent from "../component/Tabs";
 const Home = () => {
   return (
     <>
     <Header />
     <TabComponent />
     </>
   );
 };
 
 export default Home;
 