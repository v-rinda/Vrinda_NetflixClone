export const tabLabels={
    CANCEL_AT_ANY_TIME:"Cancel at any time",
    WATCH_ANYWHERE:"Watch anywhere",
    PICK_YOUR_PRICE:"Pick your price",
};
